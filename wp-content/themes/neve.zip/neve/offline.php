<?php
/**
 * The template for offline page in PWA.
 *
 * @package Neve
 * @since   2.4.3
 */

pwa_get_header( 'pwa' );

do_action( 'neve_do_offline' );

pwa_get_footer( 'pwa' );
