<?php
/**
 * Silence is golden
 *
 * This file exists to stop directory listings on poorly configured servers.
 */